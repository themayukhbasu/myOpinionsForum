<?php

	/* dev server details */
	$host = "localhost";
	$user = "root";
	$pass = "Sagarwal" ;
	$db = "forum" ; 

	/* Title Variables */
	$mainTitle =" Opinions Forum ";

?>